#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys,random
from PyQt4 import QtGui,QtCore
import makeEquation
class Paint(QtGui.QWidget):
    def __init__(self):
        super(Paint,self).__init__()
        self.initUI()
    def initUI(self):
        self.setGeometry(300,300,300,300)
#        self.show()
    def paintEvent(self, e):
    
        qp = QtGui.QPainter()
        qp.begin(self)
        self.drawPoints(qp)
        qp.end()
       
    def drawPoints(self, qp):
      
        qp.setPen(QtCore.Qt.black)
        size = self.size()
        
        for i in range(10000):
            x = random.randint(1, size.width()-1)
            y = random.randint(1, size.height()-1)
            qp.drawPoint(x, y)     

class Mainwindow(QtGui.QMainWindow):
    
    def __init__(self):
        super(Mainwindow, self).__init__()
        
        self.initUI()
        
    def initUI(self):               
        
        exitAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&Exit', self)        
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Exit application')
        exitAction.triggered.connect(QtGui.qApp.quit)

        openAction = QtGui.QAction(QtGui.QIcon.fromTheme('exit.png'),'&Open',self)
        openAction.setShortcut('Ctrl+O')
        openAction.setStatusTip('Open file')
        openAction.triggered.connect(self.fileopen_triggered)

        modelAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&ShowModel', self)        
        modelAction.triggered.connect(self.model_triggered)
        boundaryAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&ShowBoundary', self)        
        boundaryAction.triggered.connect(self.boundary_triggered)
        meshAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&Mesh', self)        
        meshAction.triggered.connect(self.mesh_triggered)
        refinedmeshAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&Refinedmesh', self)        
        refinedmeshAction.triggered.connect(self.refinedmesh_triggered)
        solverconfigureAction = QtGui.QAction(QtGui.QIcon('exit.png'), '&Configure', self)        
        solverconfigureAction.triggered.connect(self.solverconfigure_triggered)
        solveAction = QtGui.QAction(QtGui.QIcon('./pixmaps/16.gif'), '&Solve', self)        
        solveAction.triggered.connect(self.solve_triggered)
        bmapAction = QtGui.QAction(QtGui.QIcon.fromTheme('exit.png'),'&Map of B',self)
        bmapAction.triggered.connect(self.bmap_triggered)
        cloudAction = QtGui.QAction(QtGui.QIcon.fromTheme('exit.png'),'&Cloud map',self)
        cloudAction.triggered.connect(self.cloud_triggered)
        gapAction = QtGui.QAction(QtGui.QIcon.fromTheme('exit.png'),'&Gap B',self)
        gapAction.triggered.connect(self.gap_triggered)

        self.statusBar()

        menu_file = self.menuBar()
        fileMenu = menu_file.addMenu('&File')
        fileMenu.addAction(openAction)
        fileMenu.addAction(exitAction)
        fileMenu = menu_file.addMenu("&Model")
        fileMenu.addAction(modelAction)
        fileMenu = menu_file.addMenu("&Boundary")
        fileMenu.addAction(boundaryAction)
        fileMenu = menu_file.addMenu("&Mesh")
        fileMenu.addAction(meshAction)
        fileMenu.addAction(refinedmeshAction)
        fileMenu = menu_file.addMenu("&Solver")
        fileMenu.addAction(solverconfigureAction)
        fileMenu.addAction(solveAction)
        fileMenu = menu_file.addMenu("&Postprocess")
        fileMenu.addAction(bmapAction)
        fileMenu.addAction(cloudAction)
        fileMenu.addAction(gapAction)
        
        self.setGeometry(200,100,800,600)
        self.setWindowTitle('Finite elements')    
        self.show()
    def fileopen_triggered(self):
        global file_name
        file_name=QtGui.QFileDialog.getOpenFileName(self,'Open file','/home')
        print(file_name)        
    def model_triggered(self):
        modelmap=Paint()
        self.setCentralWidget(modelmap)

    def boundary_triggered(self):
        makeEquation()
        pass
    def mesh_triggered(self):
        pass
    def refinedmesh_triggered(self):
        pass
    def solverconfigure_triggered(self):
        pass
    def solve_triggered(self):
        pass
    def bmap_triggered(self):
        pass
    def cloud_triggered(self):
        pass
    def gap_triggered(self):
        pass





def main():
    
    app = QtGui.QApplication(sys.argv)
    ex = Mainwindow()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()    
